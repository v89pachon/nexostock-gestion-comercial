# Plan de pruebas manuales — NexoStock

Ejecuta estas pruebas en un navegador actualizado. Marca cada resultado al probarlo; no se afirma que hayan sido ejecutadas por un usuario externo.

| ID | Prueba | Pasos | Resultado esperado |
|---|---|---|---|
| PT01 | Abrir aplicación | Abrir `app/index.html` | Se muestran panel e indicadores con datos demo. |
| PT02 | Crear producto | Productos → Nuevo producto; completar datos válidos | El producto aparece en la tabla y en indicadores. |
| PT03 | SKU duplicado | Crear producto con SKU existente | La aplicación impide guardar y muestra aviso. |
| PT04 | Buscar producto | Escribir nombre/SKU en buscador | La tabla filtra los resultados. |
| PT05 | Crear cliente | Clientes → Nuevo cliente | El cliente aparece en la tabla. |
| PT06 | Crear pedido | Pedidos → Nuevo pedido; elegir cliente y producto | Pedido pendiente, sin descuento de inventario. |
| PT07 | Registrar venta válida | Ventas → Registrar venta; cantidad dentro del stock | Se crea venta y disminuyen existencias. |
| PT08 | Venta sin stock | Intentar vender más unidades de las disponibles | La operación se rechaza y stock no cambia. |
| PT09 | Alerta de mínimo | Crear o ajustar producto para que stock <= mínimo | Aparece alerta en panel. |
| PT10 | Cancelar pedido | Cancelar pedido pendiente | El estado cambia a cancelado; stock no cambia. |
| PT11 | Exportar reporte | Reportes → Descargar reporte CSV | Se descarga `nexostock-reporte.csv`. |
| PT12 | Exportar respaldo | Exportar datos | Se descarga JSON de respaldo. |
| PT13 | Recargar navegador | Registrar producto y recargar | Los datos permanecen en el mismo navegador. |
| PT14 | Restablecer demo | Pulsar Restablecer demo y confirmar | Se restauran los datos de ejemplo. |

**Limitación:** al ser una aplicación estática sin backend, no se pueden verificar autenticación real, concurrencia, persistencia centralizada ni seguridad de producción.
