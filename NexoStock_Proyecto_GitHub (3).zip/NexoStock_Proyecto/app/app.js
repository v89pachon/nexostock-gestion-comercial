const KEY = "nexostock-v1";
const money = n => new Intl.NumberFormat("es-CO",{style:"currency",currency:"COP",maximumFractionDigits:0}).format(Number(n)||0);
const dateNow = () => new Date().toISOString().slice(0,10);
const uid = prefix => `${prefix}-${Date.now().toString().slice(-7)}${Math.floor(Math.random()*90+10)}`;
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const seed = () => ({
  products:[
    {id:"P-1001",name:"Café molido 500 g",sku:"CAF-500",price:18000,stock:18,min:5,active:true},
    {id:"P-1002",name:"Chocolate de mesa",sku:"CHO-250",price:12500,stock:4,min:6,active:true},
    {id:"P-1003",name:"Galletas artesanales",sku:"GAL-001",price:6500,stock:32,min:8,active:true},
    {id:"P-1004",name:"Té de hierbas",sku:"TE-020",price:9000,stock:11,min:4,active:true}
  ],
  clients:[
    {id:"C-1001",name:"María Rodríguez",document:"CC 10203040",phone:"3001234567",email:"maria@example.com"},
    {id:"C-1002",name:"Andrés Gómez",document:"CC 50607080",phone:"3107654321",email:"andres@example.com"}
  ],
  orders:[], sales:[],
  users:[{id:"U-1",name:"Administrador Demo",username:"admin",role:"Administrador"}],
  currentUser:{name:"Administrador Demo",username:"admin",role:"Administrador"}
});
let db;
try { db = JSON.parse(localStorage.getItem(KEY)) || seed(); } catch { db = seed(); }
if (!db.currentUser) db.currentUser={name:"Administrador Demo",username:"admin",role:"Administrador"};
const save = () => { localStorage.setItem(KEY,JSON.stringify(db)); renderAll(); };
const el = id => document.getElementById(id);
const empty = msg => `<div class="empty">${esc(msg)}</div>`;
const statusPill = s => {
 const cls = ({Pendiente:"pill-warning",Confirmado:"pill-neutral",Completado:"pill-success",Cancelado:"pill-danger"})[s]||"pill-neutral";
 return `<span class="pill ${cls}">${esc(s)}</span>`;
};
function toast(msg){const t=el("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2400);}
function showView(name){document.querySelectorAll(".view").forEach(v=>v.classList.toggle("active",v.id===`view-${name}`));document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.view===name));const btn=document.querySelector(`[data-view="${name}"]`);el("pageTitle").textContent=btn?btn.innerText.trim().replace(/^[^\wÁÉÍÓÚÜÑ]+/,""):"Panel principal";renderAll();}
function setRoleUI(){el("userName").textContent=db.currentUser.name;el("userRole").textContent=db.currentUser.role;document.querySelectorAll(".admin-only").forEach(x=>x.style.display=db.currentUser.role==="Administrador"?"flex":"none");document.querySelectorAll(".admin-write").forEach(x=>x.style.display=db.currentUser.role==="Administrador"?"inline-flex":"none");}
function renderDashboard(){
 el("statProducts").textContent=db.products.filter(p=>p.active).length;
 el("statUnits").textContent=db.products.filter(p=>p.active).reduce((a,p)=>a+p.stock,0);
 el("statOrders").textContent=db.orders.filter(o=>["Pendiente","Confirmado"].includes(o.status)).length;
 el("statSales").textContent=money(db.sales.reduce((a,s)=>a+s.total,0));
 const sales=[...db.sales].reverse().slice(0,5);
 el("recentSales").innerHTML=sales.length?sales.map(s=>`<div class="list-row"><div><strong>${esc(s.id)} · ${esc(s.clientName)}</strong><small>${esc(s.date)} · ${s.items.length} producto(s)</small></div><strong>${money(s.total)}</strong></div>`).join(""):empty("Todavía no hay ventas registradas.");
 const low=db.products.filter(p=>p.active&&p.stock<=p.min);
 el("alertCount").textContent=`${low.length} alerta${low.length===1?"":"s"}`;
 el("lowStockList").innerHTML=low.length?low.map(p=>`<div class="list-row"><div><strong>${esc(p.name)}</strong><small>${p.stock} unidades disponibles · mínimo ${p.min}</small></div><span class="pill ${p.stock===0?"pill-danger":"pill-warning"}">${p.stock===0?"Agotado":"Stock bajo"}</span></div>`).join(""):empty("No hay productos bajo el mínimo.");
}
function renderProducts(){
 const q=el("productSearch").value.toLowerCase();
 const rows=db.products.filter(p=>`${p.name} ${p.sku}`.toLowerCase().includes(q));
 el("productCount").textContent=`${rows.length} producto(s)`;
 el("productsTable").innerHTML=rows.length?rows.map(p=>`<tr><td><div class="primary-cell">${esc(p.name)}</div><div class="sub-cell">${p.active?"Activo":"Desactivado"}</div></td><td>${esc(p.sku)}</td><td>${money(p.price)}</td><td><strong>${p.stock}</strong></td><td>${p.min}</td><td><span class="pill ${p.stock<=p.min?"pill-warning":"pill-success"}">${p.stock<=p.min?"Bajo":"Normal"}</span></td><td><div class="actions"><button class="small-button" data-edit-product="${p.id}">Editar</button><button class="small-button" data-stock="${p.id}">Ajustar</button>${p.active?`<button class="small-button danger" data-deactivate="${p.id}">Desactivar</button>`:""}</div></td></tr>`).join(""): `<tr><td colspan="7">${empty("No se encontraron productos.")}</td></tr>`;
}
function renderClients(){
 const q=el("clientSearch").value.toLowerCase(), rows=db.clients.filter(c=>`${c.name} ${c.document} ${c.email}`.toLowerCase().includes(q));
 el("clientsTable").innerHTML=rows.length?rows.map(c=>`<tr><td class="primary-cell">${esc(c.name)}</td><td>${esc(c.document)}</td><td>${esc(c.phone)}</td><td>${esc(c.email)}</td><td><div class="actions"><button class="small-button" data-edit-client="${c.id}">Editar</button><button class="small-button danger" data-delete-client="${c.id}">Eliminar</button></div></td></tr>`).join(""):`<tr><td colspan="5">${empty("No hay clientes registrados.")}</td></tr>`;
}
function itemSummary(items){return items.map(i=>`${i.qty} × ${i.name}`).join(", ");}
function renderOrders(){
 el("ordersTable").innerHTML=db.orders.length?[...db.orders].reverse().map(o=>`<tr><td class="primary-cell">${esc(o.id)}</td><td>${esc(o.clientName)}</td><td>${esc(o.date)}</td><td>${esc(itemSummary(o.items))}</td><td>${money(o.total)}</td><td>${statusPill(o.status)}</td><td><div class="actions">${o.status==="Pendiente"?`<button class="small-button" data-order-confirm="${o.id}">Confirmar</button>`:""}${["Pendiente","Confirmado"].includes(o.status)?`<button class="small-button" data-order-sale="${o.id}">Convertir en venta</button><button class="small-button danger" data-order-cancel="${o.id}">Cancelar</button>`:""}</div></td></tr>`).join(""):`<tr><td colspan="7">${empty("No hay pedidos registrados.")}</td></tr>`;
}
function renderSales(){
 el("salesTable").innerHTML=db.sales.length?[...db.sales].reverse().map(s=>`<tr><td class="primary-cell">${esc(s.id)}</td><td>${esc(s.clientName)}</td><td>${esc(s.date)}</td><td>${esc(itemSummary(s.items))}</td><td>${money(s.total)}</td><td><button class="small-button" data-sale-detail="${s.id}">Ver detalle</button></td></tr>`).join(""):`<tr><td colspan="6">${empty("Todavía no hay ventas.")}</td></tr>`;
}
function renderReports(){
 const total=db.sales.reduce((a,s)=>a+s.total,0), low=db.products.filter(p=>p.active&&p.stock<=p.min);
 el("reportRevenue").textContent=money(total);el("reportSalesCount").textContent=db.sales.length;el("reportAverage").textContent=money(db.sales.length?total/db.sales.length:0);el("reportLow").textContent=low.length;
 el("inventorySummary").innerHTML=db.products.length?`<div class="list-row"><div><strong>Referencias activas</strong></div><strong>${db.products.filter(p=>p.active).length}</strong></div><div class="list-row"><div><strong>Unidades totales disponibles</strong></div><strong>${db.products.reduce((a,p)=>a+(p.active?p.stock:0),0)}</strong></div><div class="list-row"><div><strong>Valor estimado del inventario</strong><small>Existencias × precio de venta</small></div><strong>${money(db.products.filter(p=>p.active).reduce((a,p)=>a+p.stock*p.price,0))}</strong></div>`:empty("Sin productos.");
}
function renderUsers(){el("usersTable").innerHTML=db.users.map(u=>`<tr><td class="primary-cell">${esc(u.name)}</td><td>${esc(u.username)}</td><td>${esc(u.role)}</td><td>${u.username==="admin"?'<span class="muted">Cuenta demo protegida</span>':`<button class="small-button danger" data-delete-user="${u.id}">Eliminar</button>`}</td></tr>`).join("");}
function renderAll(){setRoleUI();renderDashboard();renderProducts();renderClients();renderOrders();renderSales();renderReports();renderUsers();}
function openModal(title, body, submit){el("modalTitle").textContent=title;el("modalBody").innerHTML=body;el("appDialog").showModal();el("modalForm").onsubmit=e=>{e.preventDefault();const fd=new FormData(e.target);if(submit(fd) !== false){el("appDialog").close();e.target.reset();save();}};}
function field(label,name,value="",type="text",required=true,extra=""){return `<div class="field"><label>${label}</label><input name="${name}" type="${type}" value="${esc(value)}" ${required?"required":""} ${extra}></div>`;}
function addProduct(existing=null){
 if(db.currentUser.role!=="Administrador"){toast("Solo el administrador puede modificar productos.");return;}
 const p=existing||{name:"",sku:"",price:"",stock:0,min:2};
 openModal(existing?"Editar producto":"Nuevo producto",`<div class="form-grid">${field("Nombre del producto","name",p.name)}${field("Código SKU","sku",p.sku)}${field("Precio de venta (COP)","price",p.price,"number",true,'min="1" step="1"')}${field("Existencias iniciales","stock",p.stock,"number",true,'min="0" step="1"')}${field("Nivel mínimo de inventario","min",p.min,"number",true,'min="0" step="1"')}</div>`,fd=>{
  const name=fd.get("name").trim(),sku=fd.get("sku").trim().toUpperCase(),price=Number(fd.get("price")),stock=Number(fd.get("stock")),min=Number(fd.get("min"));
  if(db.products.some(x=>x.sku.toLowerCase()===sku.toLowerCase()&&x.id!==p.id)){toast("Ese SKU ya existe.");return false;}
  if(price<=0||stock<0||min<0||![price,stock,min].every(Number.isFinite)){toast("Verifica los valores numéricos.");return false;}
  if(existing)Object.assign(existing,{name,sku,price,stock,min});else db.products.push({id:uid("P"),name,sku,price,stock,min,active:true});
  toast("Producto guardado correctamente.");
 });
}
function addClient(existing=null){
 const c=existing||{name:"",document:"",phone:"",email:""};
 openModal(existing?"Editar cliente":"Nuevo cliente",`<div class="form-grid">${field("Nombre completo","name",c.name)}${field("Documento","document",c.document)}${field("Teléfono","phone",c.phone,"tel")}${field("Correo electrónico","email",c.email,"email",false)}</div>`,fd=>{
  const name=fd.get("name").trim(),document=fd.get("document").trim();
  if(!name){toast("Escribe el nombre del cliente.");return false;}
  if(db.clients.some(x=>x.document&&x.document===document&&x.id!==c.id)){toast("Ya existe un cliente con ese documento.");return false;}
  if(existing)Object.assign(existing,{name,document,phone:fd.get("phone").trim(),email:fd.get("email").trim()});else db.clients.push({id:uid("C"),name,document,phone:fd.get("phone").trim(),email:fd.get("email").trim()});
  toast("Cliente guardado.");
 });
}
function itemForm(initialItems=[]){
 const clients=db.clients.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join("");
 const products=db.products.filter(p=>p.active).map(p=>`<option value="${p.id}">${esc(p.name)} — ${p.stock} disponibles — ${money(p.price)}</option>`).join("");
 if(!clients||!products)return {html:`<p class="notice">Debes registrar al menos un cliente y un producto activo antes de continuar.</p>`,valid:false};
 const line=(idx,item={productId:db.products.find(p=>p.active)?.id,qty:1})=>`<div class="line-item"><div class="field"><label>Producto</label><select name="product_${idx}" required>${db.products.filter(p=>p.active).map(p=>`<option value="${p.id}" ${p.id===item.productId?"selected":""}>${esc(p.name)} · ${p.stock} disp.</option>`).join("")}</select></div><div class="field"><label>Cantidad</label><input name="qty_${idx}" type="number" min="1" step="1" value="${item.qty||1}" required></div></div>`;
 return {valid:true,html:`<div class="form-grid">${`<div class="field full"><label>Cliente</label><select name="clientId" required>${clients}</select></div>`}</div><div id="orderLines">${line(0,initialItems[0])}</div><button type="button" id="addLine" class="button button-light">＋ Agregar otro producto</button><div class="total-line"><span>Total estimado</span><strong id="formTotal">$0</strong></div><p class="muted">Las cantidades se validan contra el inventario disponible al guardar.</p>`,line};
}
function collectItems(fd){
 const items=[];
 for(let i=0;i<20;i++){const pid=fd.get(`product_${i}`);if(!pid)continue;const qty=Number(fd.get(`qty_${i}`)),p=db.products.find(x=>x.id===pid);if(!p||!Number.isInteger(qty)||qty<1){toast("Revisa los productos y cantidades.");return null;}items.push({productId:p.id,name:p.name,qty,price:p.price,subtotal:p.price*qty});}
 if(!items.length){toast("Agrega al menos un producto.");return null;}
 const counts={};items.forEach(i=>counts[i.productId]=(counts[i.productId]||0)+i.qty);
 for(const [pid,qty] of Object.entries(counts)){const p=db.products.find(x=>x.id===pid);if(qty>p.stock){toast(`Stock insuficiente para ${p.name}. Disponible: ${p.stock}.`);return null;}}
 return items;
}
function bindOrderLines(){let n=1;el("addLine")?.addEventListener("click",()=>{if(n>=10){toast("Máximo 10 líneas por operación.");return;}el("orderLines").insertAdjacentHTML("beforeend",itemForm().line(n++));el("orderLines").querySelectorAll("select,input").forEach(x=>x.addEventListener("change",updateTotal));updateTotal();});el("orderLines")?.querySelectorAll("select,input").forEach(x=>x.addEventListener("change",updateTotal));el("modalBody").querySelector('[name="clientId"]')?.addEventListener("change",updateTotal);updateTotal();}
function updateTotal(){const form=el("modalForm");if(!form)return;let total=0;for(let i=0;i<10;i++){const pid=form.elements[`product_${i}`]?.value,qty=Number(form.elements[`qty_${i}`]?.value||0),p=db.products.find(x=>x.id===pid);if(p&&qty>0)total+=p.price*qty;}if(el("formTotal"))el("formTotal").textContent=money(total);}
function addOrder(){
 const f=itemForm();if(!f.valid){toast("Primero registra clientes y productos.");return;}
 openModal("Crear pedido",f.html,fd=>{const items=collectItems(fd);if(!items)return false;const c=db.clients.find(x=>x.id===fd.get("clientId"));db.orders.push({id:uid("PED"),clientId:c.id,clientName:c.name,date:dateNow(),items,total:items.reduce((a,i)=>a+i.subtotal,0),status:"Pendiente"});toast("Pedido creado. Aún no descuenta inventario.");});bindOrderLines();
}
function addSale(order=null){
 const f=itemForm(order?.items||[]);if(!f.valid){toast("Primero registra clientes y productos.");return;}
 openModal(order?"Convertir pedido en venta":"Registrar venta",f.html,fd=>{const items=collectItems(fd);if(!items)return false;const c=db.clients.find(x=>x.id===fd.get("clientId"));items.forEach(i=>{const p=db.products.find(x=>x.id===i.productId);p.stock-=i.qty;});db.sales.push({id:uid("VEN"),clientId:c.id,clientName:c.name,date:dateNow(),items,total:items.reduce((a,i)=>a+i.subtotal,0),sourceOrderId:order?.id||null});if(order){order.status="Completado";}toast("Venta registrada e inventario actualizado.");});bindOrderLines();if(order){el("modalBody").querySelector('[name="clientId"]').value=order.clientId;updateTotal();}
}
function exportCSV(filename, rows){const csv=rows.map(r=>r.map(v=>`"${String(v??"").replace(/"/g,'""')}"`).join(";")).join("\r\n");const blob=new Blob(["\ufeff"+csv],{type:"text/csv;charset=utf-8;"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=filename;a.click();URL.revokeObjectURL(a.href);}
function exportReport(){const rows=[["Tipo","ID","Fecha","Cliente","Detalle","Total COP"]];db.sales.forEach(s=>rows.push(["Venta",s.id,s.date,s.clientName,itemSummary(s.items),s.total]));rows.push([]);rows.push(["Inventario","SKU","Producto","Existencias","Mínimo","Precio COP"]);db.products.forEach(p=>rows.push(["Producto",p.sku,p.name,p.stock,p.min,p.price]));exportCSV("nexostock-reporte.csv",rows);toast("Reporte descargado.");}
function exportAll(){const blob=new Blob([JSON.stringify(db,null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="nexostock-respaldo.json";a.click();URL.revokeObjectURL(a.href);toast("Copia de respaldo descargada.");}
document.addEventListener("click",e=>{
 const b=e.target.closest("button");if(!b)return;
 if(b.dataset.view)showView(b.dataset.view);if(b.dataset.goto)showView(b.dataset.goto);
 if(b.id==="addProduct")addProduct();if(b.id==="addClient")addClient();if(b.id==="addOrder")addOrder();if(b.id==="addSale")addSale();if(b.id==="exportReport")exportReport();if(b.id==="exportAll")exportAll();
 if(b.id==="cancelModal"||b.id==="closeModal")el("appDialog").close();
 if(b.id==="logout"){openModal("Cambiar usuario demo",`<div class="form-grid">${field("Usuario","username","admin") }<div class="field"><label>Rol</label><select name="role"><option>Administrador</option><option>Empleado</option></select></div></div><p class="muted">El cambio es solo demostrativo; no representa autenticación segura.</p>`,fd=>{const u=db.users.find(x=>x.username===fd.get("username"));if(!u){toast("Usuario no encontrado.");return false;}db.currentUser={name:u.name,username:u.username,role:fd.get("role")==="Empleado"?"Empleado":u.role};toast("Vista de usuario actualizada.");});}
 if(b.id==="resetDemo"&&confirm("¿Restablecer todos los datos al ejemplo inicial? Esta acción no se puede deshacer.")){db=seed();save();toast("Datos de demostración restablecidos.");}
 if(b.dataset.editProduct)addProduct(db.products.find(p=>p.id===b.dataset.editProduct));
 if(b.dataset.stock){const p=db.products.find(p=>p.id===b.dataset.stock);openModal("Ajuste de inventario",`<p>Existencias actuales de <strong>${esc(p.name)}</strong>: ${p.stock}</p><div class="form-grid">${field("Cambio de unidades (+/-)","delta","0","number",true,'step="1"')}${field("Motivo","reason","","text",true)}</div>`,fd=>{const delta=Number(fd.get("delta"));if(!Number.isInteger(delta)||p.stock+delta<0){toast("El ajuste no puede dejar inventario negativo.");return false;}p.stock+=delta;toast("Ajuste registrado. Documenta el motivo en el control operativo del negocio.");});}
 if(b.dataset.deactivate){const p=db.products.find(p=>p.id===b.dataset.deactivate);if(confirm(`¿Desactivar ${p.name}?`)){p.active=false;save();toast("Producto desactivado.");}}
 if(b.dataset.editClient)addClient(db.clients.find(c=>c.id===b.dataset.editClient));
 if(b.dataset.deleteClient){const c=db.clients.find(x=>x.id===b.dataset.deleteClient);if(db.orders.some(o=>o.clientId===c.id)||db.sales.some(s=>s.clientId===c.id)){toast("No se puede eliminar: tiene operaciones asociadas.");}else if(confirm(`¿Eliminar a ${c.name}?`)){db.clients=db.clients.filter(x=>x.id!==c.id);save();toast("Cliente eliminado.");}}
 if(b.dataset.orderConfirm){const o=db.orders.find(x=>x.id===b.dataset.orderConfirm);o.status="Confirmado";save();toast("Pedido confirmado.");}
 if(b.dataset.orderCancel){const o=db.orders.find(x=>x.id===b.dataset.orderCancel);if(confirm("¿Cancelar este pedido? No se había descontado inventario.")){o.status="Cancelado";save();toast("Pedido cancelado.");}}
 if(b.dataset.orderSale){const o=db.orders.find(x=>x.id===b.dataset.orderSale);addSale(o);}
 if(b.dataset.saleDetail){const s=db.sales.find(x=>x.id===b.dataset.saleDetail);openModal(`Detalle ${s.id}`,`<p><strong>Cliente:</strong> ${esc(s.clientName)}<br><strong>Fecha:</strong> ${s.date}</p><div class="table-wrap"><table><thead><tr><th>Producto</th><th>Cantidad</th><th>Subtotal</th></tr></thead><tbody>${s.items.map(i=>`<tr><td>${esc(i.name)}</td><td>${i.qty}</td><td>${money(i.subtotal)}</td></tr>`).join("")}</tbody></table></div><div class="total-line"><span>Total</span><strong>${money(s.total)}</strong></div>`,()=>true);}
 if(b.id==="addUser"){openModal("Nuevo usuario demo",`<div class="form-grid">${field("Nombre","name")}${field("Nombre de usuario","username") }<div class="field"><label>Rol</label><select name="role"><option>Empleado</option><option>Administrador</option></select></div></div><p class="muted">No se guardan contraseñas; esto solo simula perfiles para la demostración.</p>`,fd=>{const username=fd.get("username").trim();if(db.users.some(u=>u.username===username)){toast("Ese usuario ya existe.");return false;}db.users.push({id:uid("U"),name:fd.get("name").trim(),username,role:fd.get("role")});toast("Usuario demo agregado.");});}
 if(b.dataset.deleteUser){const u=db.users.find(x=>x.id===b.dataset.deleteUser);if(confirm(`¿Eliminar usuario ${u.username}?`)){db.users=db.users.filter(x=>x.id!==u.id);save();toast("Usuario eliminado.");}}
});
el("productSearch").addEventListener("input",renderProducts);el("clientSearch").addEventListener("input",renderClients);
el("today").textContent=new Intl.DateTimeFormat("es-CO",{dateStyle:"medium"}).format(new Date());el("year").textContent=new Date().getFullYear();
renderAll();
